public class DateInfo
{
   Game[] games;
}  