public class Game
{
   TeamInfo teams;
}   