public class GameInfo
{
   DateInfo[] dates;
}