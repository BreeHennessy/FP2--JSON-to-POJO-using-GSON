public class Stats 
{
    String name;
    int score;
}
