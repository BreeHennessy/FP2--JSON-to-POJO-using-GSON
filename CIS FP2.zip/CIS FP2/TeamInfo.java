public class TeamInfo 
{
    Stats away;
    Stats home;
}
