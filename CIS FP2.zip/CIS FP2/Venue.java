public class Venue 
{
    String name;
    int id;
}
